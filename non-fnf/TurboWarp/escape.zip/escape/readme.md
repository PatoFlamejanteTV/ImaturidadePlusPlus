# O que é isso?
Basciamente **isso é um arquivo .BIN**, contendo um arquivo *.html*, que é um **mini-jogo que pode ser ativado no final/meio/começo e músicas usando `os.execute()` em Lua.**
## Por que?
Para deixar mais "secreto" e não ficar óbvio que "Há AlGo AsSuStAdOr NeSsE MoD UuUuUuUuUHHH".
## Muahahaah eu vou vazar tudo daqui/Fazer teorias maluquinhas sem nem ter chegado naquela parte >:)
Dboa, **eu não quero esconder esses níveis de ninguem, mas saiba que provavlemente sua diversão vai por krl quando jogar os nível de ordem aleatória.**

Principalmente pelos *Spoilers.*
